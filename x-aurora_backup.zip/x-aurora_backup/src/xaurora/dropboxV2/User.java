package xaurora.dropboxV2;

public class User {
	 public String username;
	 public String dropboxAccessToken;
}
