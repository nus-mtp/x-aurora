package xaurora.io;
import xaurora.util.*;
public class PreferenceIO {
	public static void updatePreference(UserPreference p){
		
	}
}
